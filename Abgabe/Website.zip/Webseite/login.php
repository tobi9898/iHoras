<!DOCTYPE html>

<?php
	session_start();
    if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
       $user = $_SESSION['Benutzername'];
		       header('Location: index.php');
		die();

    }
	require_once 'php/connect_db.php';
?>

<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>iHoras - Login</title>

<!-- Favicon -->
<link rel="shortcut icon" href="img/ihoras-fav.png">

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/normalize.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="css/login.css">


</head>
<body>
    
 

<div class="container">
	<div id="login-box">
		<div class="logo">
			<img src="img/clock.png" width="120px" height="120px" class="img img-responsive center-block" alt="clock"/>
			<h1 class="logo-caption"><span class="tweak">i</span>horas</h1>
		</div><!-- /.logo -->
		<div class="controls">
		<form action="" method="post">
			<input type="text" name="Benutzername" id="Benutzername" placeholder="Benutzername" class="form-control" />
			<input type="password" name="password" id="password" placeholder="Passwort" class="form-control" />
			<button type="submit" formmethod="post" class="btn btn-default btn-block btn-custom">Anmeldem</button>
			</form>
		</div><!-- /.controls -->
	</div><!-- /#login-box -->
</div><!-- /.container -->
   
   	<div id="particles-js"></div>

    
    <?php
       
if(isset($_POST['Benutzername']) && isset($_POST['password'])){     

    $hash =  md5($_POST['password']);            
    $Benutzer=  $_POST['Benutzername'];
   // echo $Benutzer,$hash;
             
        
 $Result = $pdo->prepare("select Benutzername, Passwort, Typ from Benutzer where Benutzername = ? and Passwort = ?");
            
    $Result->execute(array($Benutzer,$hash));
    
    $datensatz=$Result->fetch( PDO::FETCH_ASSOC );
    
                                                    
if( $Benutzer!=NULL && $datensatz['Passwort'] == $hash && $datensatz['Benutzername'] == $Benutzer){
                         
                $_SESSION['Benutzername'] = $Benutzer;
                $_SESSION['Passwort'] = $hash;
				$_SESSION['Typ'] = $datensatz['Typ'];
            
                if($datensatz['Typ']=="Sekretariat")
                {
                    header("Location: sek.php");
					die();
                    
                }else{
                    if($datensatz['Typ']=="Administrator"){
                    
                        header("Location: admin.php");  //Admin Panel verlinken
						die();
                    }else{                                        
				        header("Location: index.php");
						die();
                    }
                }
			}else{
             
				header("Location: login.php");
	
	die();
                
                
			}
		 
}

	?>


	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>

	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.js"></script>
	
	<!--Particles.js -->
	<script src="js/particles.js" type="text/javascript"></script>

	<!-- Login JS -->
	<script src="js/init.js"></script>

</body>

</html>