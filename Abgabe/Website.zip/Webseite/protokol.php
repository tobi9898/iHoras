<?php
session_start();
if ( isset( $_SESSION[ 'Benutzername' ] ) && isset( $_SESSION[ 'Passwort' ] ) ) {
	$user = $_SESSION[ 'Benutzername' ];
} else {
	header( 'Location: ../login.php' );
}

require_once 'php/connect_db.php';
?>

<!DOCTYPE html>
<html lang="de">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>iHoras - Protokoll</title>

	<!-- Favicon -->
	<link rel="shortcut icon" href="img/ihoras-fav.png">

	<!-- Bootstrap -->
	<link href="css/bootstrap.css" rel="stylesheet">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">

</head>

<body class="container-fluid">
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.php">iHoras</a>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="defaultNavbar1">
				<ul class="nav navbar-nav">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Funktionen<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="index.php">Dashboard</a>
							</li>
							<li class="divider"></li>
							<li><a href="calendar.php">Kalender</a>
							</li>
							<li><a href="protokol.php">Protokolle</a>
							</li>
						</ul>
					</li>
					<li><a href="help.php">Hilfe</a>

				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="profil.php">Profil</a>
							</li>
							<li><a href="php/logout.php">Abmelden</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
			<!-- /.navbar-collapse -->
		</div>
		<!-- /.container-fluid -->
	</nav>
	<div style="height: 60px"></div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<h1 class="text-center headline">iHoras - Protokoll</h1>
			</div>
		</div>
		<hr>
	</div>

	<div class="container-fluid">
		<textarea></textarea>
	</div>


<div class="container-fluid">
	<hr>
	<div class="row">
		<div class="text-center col-md-6 col-md-offset-3">
			<p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; <a href="http://www.simon-mayrhofer.com/">iHoras</a>
			</p>
		</div>
	</div>
	</div>
	
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>

	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.js"></script>

	<!-- TinyMCE JS -->
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=jo37kj6hhe80ivv2w8765ks90uqan3vcyr20qhqesoa0z0fn"></script>
	<script>
		tinymce.init( {
			selector: 'textarea',
			height: 500,
			theme: 'modern',
			plugins: [
				'advlist autolink lists link image charmap print preview hr anchor pagebreak',
				'searchreplace wordcount visualblocks visualchars code fullscreen',
				'insertdatetime media nonbreaking save table contextmenu directionality',
				'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
			],
			toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
			toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
			image_advtab: true,
			templates: [ {
				title: 'Test template 1',
				content: 'Test 1'
			}, {
				title: 'Test template 2',
				content: 'Test 2'
			} ],
			content_css: [
				'//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
				'//www.tinymce.com/css/codepen.min.css'
			]
		} );
	</script>

</body>

</html>