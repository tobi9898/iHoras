<?php
session_start();
if ( isset( $_SESSION[ 'Benutzername' ] ) && isset( $_SESSION[ 'Passwort' ] ) ) {

	$user = $_SESSION[ 'Benutzername' ];

	if ( $_SESSION[ 'Typ' ] == "Administrator" ) {

		header( 'Location: admin.php' );
		die();

	} else if ( $_SESSION[ 'Typ' ] == "Lehrer" ) {

		header( 'Location: index.php' );
		die();
	}

} else {
	header( 'Location: login.php' );
	die();
}
require_once 'php/connect_db.php';
?>




<!DOCTYPE html>
<html lang="de">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>iHoras - Dashboard</title>

	<!-- Favicon -->
	<link rel="shortcut icon" href="img/ihoras-fav.png">

	<!-- Bootstrap -->
	<link href="css/bootstrap.css" rel="stylesheet">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">
</head>

<body class="container-fluid">

	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<a class="navbar-brand" href="sek.php">iHoras</a>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="defaultNavbar1">
				<ul class="nav navbar-nav">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Funktionen<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="sek.php">Dashboard</a>
							</li>
						</ul>
					</li>

				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="sekprofil.php">Profil</a>
							</li>

							<li><a href="php/logout.php">Abmelden</a>

							</li>
						</ul>
					</li>
				</ul>
			</div>
			<!-- /.navbar-collapse -->
		</div>
		<!-- /.container-fluid -->
	</nav>
	<div style="height: 60px"></div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<h1 class="text-center headline">Herzlich Willkommen <?php echo $_SESSION["Benutzername"]; ?></h1>
			</div>
		</div>
	</div>

	<?php

	$stmt0 = $pdo->prepare( "select * from  Protokolle order by Datum desc" );

	$stmt0->execute();

	?>

	<!-- tt></-->
	<div class="tablewidth">
		<h2>Protokolle</h2>
		<div class="row">
			<table class="table" style="align-items: center">
				<thead>
					<tr>
						<th>Datum</th>
						<th>Protokollant</th>
						<th>Art</th>
						<th>Dauer</th>
						<th>Protokoll</th>
					</tr>
				</thead>
				<tbody>


					<?php 
                       while ($result0 = $stmt0->fetch( PDO::FETCH_ASSOC ))      
                    {
                          echo"<tr>";
                            
                            
                            echo "<td>"	;
                            
                           echo $result0["Datum"];
							
                            echo "</td> ";
                            
 	
                            echo "<td>"	;
                            
                           echo $result0["Protokolant"];
							
                            echo "</td> ";
                            
                            	
                            echo "<td>"	;
                            
                           echo $result0["Art"];
							
                            echo "</td> ";
                           	
                            echo "<td>"	;
                            
                           echo $result0["Dauer"];
							
                            echo "</td> ";
                           
                             echo "<td>"	;
                            
                           echo $result0["Text"];
							
                            echo "</td> ";
                            
                            echo"</tr>";
                       }
                            ?>

				</tbody>
			</table>
		</div>
	</div>
	<div class="container-fluid">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title txtalign"> Auffüllstunden nach Lehrer</h3>
			</div>
			<div class="panel-body">

				<div class="container-fluid">
					<form class="form-horizontal" action="./sek.php" method="post">
						<div class="form-group">
							<label class="control-label col-sm-2" for="typ">Lehrer auswählen:</label>
							<div class="col-sm-10">
								<select class="form-control" id="typl" name="typl">

									<?php 	
	  								echo "<option value='default' selected>Lehrer auswählen</option>";
									$stmt0=$pdo->prepare("Select Benutzername, Name from Benutzer where Typ = 'Lehrer'");								     $stmt0->execute();
									while($result0 = $stmt0->fetch(PDO::FETCH_ASSOC))
									{
									$temp='"'.$result0[ "Benutzername"].'"';
									echo "<option value=$temp >" . $result0[ "Name"] . "</option>";
									} 
								?>

								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">

								<button type="submit" class="btn btn-default">Suchen</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<?php

	$stmt2 = $pdo->prepare( "SELECT neuTyp, Datum, Zeit, Dauer, Beschreibung FROM ((SELECT ID, Typ as neuTyp, Dauer, Beschreibung, Datum, Zeit FROM Auffullstunden WHERE ID NOT IN ( SELECT AID AS ID FROM KollegialeTatigkeiten )) t  natural join (SELECT * FROM Benutzer  NATURAL JOIN BenutzerAuf WHERE Benutzername = ? and Freigeben = 1) t2 )" );
	if ( $_POST[ "typl" ] != null ) {
		$stmt2->execute( array( $_POST[ 'typl' ] ) );
	}
	?>

	<!-- tt></-->
	<div class="tablewidth">
		<h2>Auffüllstunden von <?php echo $_POST["typl"]; ?>
			</h2>
		<div class="row">
			<table class="table" style="align-items: center">
				<thead>
					<tr>
						<th>Typ</th>
						<th>Beschreibung</th>
						<th>Datum</th>
						<th>Uhrzeit</th>
						<th>Dauer</th>
					</tr>
				</thead>
				<tbody>


					<?php 
                       while ($result3 = $stmt2->fetch( PDO::FETCH_ASSOC ))      
                    {
                          echo"<tr>";
                            
                            echo "<td>"	;
                            
                           echo $result3["neuTyp"];
							
                            echo "</td> ";
						echo "<td>"	;
                            
                           echo $result3["Beschreibung"];
							
                            echo "</td> ";
						
                            echo "<td>"	;
                            
                           echo $result3["Datum"];
							
                            echo "</td> ";
						
						
						   echo "<td>"	;
   
                           echo $result3["Zeit"];
							
                            echo "</td> ";
						                           
                             echo "<td>"	;
   
                           echo $result3["Dauer"];
							
                            echo "</td> ";

                       }
                            ?>

				</tbody>
			</table>
		</div>
	</div>
	
		

	
	<?php

	$stmt2 = $pdo->prepare( "SELECT neuTyp, Datum, Zeit, Dauer, Beschreibung FROM ((SELECT ID, Typ as neuTyp, Dauer, Beschreibung, Datum, Zeit FROM Auffullstunden WHERE ID IN ( SELECT AID AS ID FROM KollegialeTatigkeiten )) t  natural join (SELECT * FROM Benutzer  NATURAL JOIN BenutzerAuf WHERE Benutzername = ? and Freigeben = 1) t2 )" );
	if ( $_POST[ "typl" ] != null ) {
		$stmt2->execute( array( $_POST[ 'typl' ] ) );
	}
	?>

	<!-- tt></-->
	<div class="tablewidth">
		<h2>Kollegiale Tätigkeiten von <?php echo $_POST["typl"]; ?></h2>
		<div class="row">
			<table class="table" style="align-items: center">
				<thead>
					<tr>
						<th>Typ</th>
						<th>Beschreibung</th>
						<th>Datum</th>
						<th>Uhrzeit</th>
						<th>Dauer</th>
					</tr>
				</thead>
				<tbody>


					<?php 
                       while ($result3 = $stmt2->fetch( PDO::FETCH_ASSOC ))      
                    {
                          echo"<tr>";
                            
                            echo "<td>"	;
                            
                           echo $result3["neuTyp"];
							
                            echo "</td> ";
						echo "<td>"	;
                            
                           echo $result3["Beschreibung"];
							
                            echo "</td> ";
						
                            echo "<td>"	;
                            
                           echo $result3["Datum"];
							
                            echo "</td> ";
						
						
						   echo "<td>"	;
   
                           echo $result3["Zeit"];
							
                            echo "</td> ";
						                           
                             echo "<td>"	;
   
                           echo $result3["Dauer"];
							
                            echo "</td> ";

                       }
                            ?>

				</tbody>
			</table>
		</div>
	</div>


	<!-- tt></-->
	<div class="container-fluid"></div>
	<hr>
	<div class="row">
		<div class="text-center col-md-6 col-md-offset-3">
			<p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; iHoras</a>
			</p>
		</div>
	</div>
	</div>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>

	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.js"></script>

	<!-- Datanbankanbindung -->
	<script src="js/init.js"></script>
</body>

</html>