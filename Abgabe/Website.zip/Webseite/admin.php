<?php
 session_start();
if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
    
          $user = $_SESSION['Benutzername'];

        if($_SESSION['Typ']=="Sekretariat"){

            header('Location: sek.php');
			die();

        }else if($_SESSION['Typ']=="Lehrer"){

             header('Location: index.php');
			die();
        }
                        
    }else{
          header('Location: login.php');
	die();
        }
        require_once 'php/connect_db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>iHoras - Admin</title>

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<link rel="shortcut icon" href="img/ihoras-fav.png"

</head>
<body class="container-fluid">
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid"> 
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
      <a class="navbar-brand" href="admin.php">iHoras</a></div>
    <div class="collapse navbar-collapse" id="defaultNavbar1">
      <ul class="nav navbar-nav">
        <li class=""><a href="insert.php">Einfügen<span class="sr-only"></span></a></li>
        <li class=""><a href="delete.php">Löschen<span class="sr-only"></span></a></li>
        <li class=""><a href="update.php">Ändern<span class="sr-only"></span></a></li>
      </ul>
       <ul class="nav navbar-nav navbar-right">
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="php/logout.php">Abmelden</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<div style="height: 70px"></div>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
				<h1 class="text-center headline">Herzlich Willkommen <?php echo $_SESSION["Benutzername"]; ?></h1>
    </div>
  </div>
  <hr>
</div>

    
    <div class="hourpanel center-block">

		<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title txtalign"> Aktion ausführen</h3>
		</div>
			<div class="panel-body">
			
    <div class="form-group txtalign">
    <a href="insert.php" class="btn btn-primary margintop">Neuen Benutzer anlegen</a>
	</div>
   <div class="form-group txtalign">
    <a href="update.php" class="btn btn-primary margintop">Benutzer ändern</a>
	</div>
   <div class="form-group txtalign">
    <a href="delete.php" class="btn btn-primary margintop">Benutzer löschen</a>
	</div>
   <div class="form-group txtalign">
    <a class="btn btn-primary margintop" onclick="resetcheck()">Auffüllstunden zurücksetzen</a>
	</div>
			</div>
		</div>
	</div>


<div class="container-fluid">
<hr>
  <div class="row">
    <div class="text-center col-md-6 col-md-offset-3">
      <p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; iHoras</p>
    </div>
  </div>
	</div>
	
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.3.min.js"></script> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
    
<script type="text/javascript" src="js/init.js"></script>
</body>
</html>
