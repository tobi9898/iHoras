<?php
	session_start();
     if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
        $user = $_SESSION['Benutzername'];
     }else{
        header('Location: ../login.php');
     }

	require_once 'php/connect_db.php';
?>

<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>iHoras - Kalender</title>

<!-- Favicon -->
<link rel="shortcut icon" href="img/ihoras-fav.png">

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/fullcalendar.css" rel="stylesheet">
<link href="css/fullcalendar.print.css" rel="stylesheet" media="print">
<link rel="stylesheet" href="css/normalize.css">
<link rel="stylesheet" href="css/style.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
      <a class="navbar-brand" href="index.php">iHoras</a></div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="defaultNavbar1">
      <ul class="nav navbar-nav">
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Funktionen<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="index.php">Dashboard</a></li>
            <li class="divider"></li>
            <li><a href="calendar.php">Kalender</a></li>
            <li><a href="protokol.php">Protokolle</a></li>
          </ul>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="profil.php">Profil</a></li>
            <li><a href="php/logout.php">Abmelden</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<div style="height: 40px"></div>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <h1 class="text-center headline">iHoras - Kalender</h1>
    </div>
  </div>
  <hr>
</div>
  
  <div class="container-fluid cal">
  	<div id="calendar"></div>
	</div>


  <hr>
  <div class="row">
    <div class="text-center col-md-6 col-md-offset-3">
      <p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; <a href="http://www.simon-mayrhofer.com/" >iHoras</a></p>
    </div>
  </div>
  <hr>
 
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.3.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>

<!-- FullCalendarJs -->
<script src="js/moment.min.js"></script>
<script src="js/fullcalendar.js"></script>
<script src="js/de.js"></script>

<script>

	$(document).ready(function() {
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,basicWeek,basicDay'
			},
			defaultDate: '2017-05-12',
			navLinks: true, // can click day/week names to navigate views
			editable: true,
			eventLimit: true, // allow "more" link when too many events
			events: 
			
			[
				
				
				
				<?php
				session_start();
     			if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
					$user = $_SESSION['Benutzername'];
     			}else{
					header('Location: ../login.php');
     			}

				require_once 'php/connect_db.php';

				$stmt1=$pdo->prepare("select * from Auffullstunden natural join (select * from Benutzer natural join BenutzerAuf where Benutzername = ?)");
				$stmt1->execute(array($_SESSION["Benutzername"]));

				
				$result1 = $stmt1->fetch(PDO::FETCH_ASSOC);

				
				
				$stmt2=$pdo->prepare("insert into BenutzerAuf values (?, ?)");
				$stmt2->execute(array($_SESSION["Benutzername"], $result1['ID']));
				
				?>
				
				
				
				
				{
					title: 'All Day Event',
					start: '2017-05-01'
				},
				{
					title: 'Long Event',
					start: '2017-05-07',
					end: '2017-05-10'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2017-05-09T16:00:00'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2017-05-16T16:00:00'
				},
				{
					title: 'Conference',
					start: '2017-05-11',
					end: '2017-05-13'
				},
				{
					title: 'Meeting',
					start: '2017-05-12T10:30:00',
					end: '2017-05-12T12:30:00'
				},
				{
					title: 'Lunch',
					start: '2017-05-12T12:00:00'
				},
				{
					title: 'Meeting',
					start: '2017-05-12T14:30:00'
				},
				{
					title: 'Happy Hour',
					start: '2017-05-12T17:30:00'
				},
				{
					title: 'Dinner',
					start: '2017-05-12T20:00:00'
				},
				{
					title: 'Birthday Party',
					start: '2017-05-13T07:00:00'
				},
				{
					title: 'Click for Google',
					url: 'http://google.com/',
					start: '2017-05-28'
				}
			]
			
			
			
			
			
			
			
		});
		
	});

</script>	

</body>
</html>
