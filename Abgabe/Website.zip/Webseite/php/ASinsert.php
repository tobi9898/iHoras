<?php
     session_start();
     if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
        $user = $_SESSION['Benutzername'];
     }else{
        header('Location: ../login.php');
     }

	require_once 'connect_db.php';

	$stmt=$pdo->prepare("select * from Auffullstunden where Typ = ? and Beschreibung = ? and Datum = ? and Dauer = ? and Zeit = ?");
    $stmt->execute(array($_POST["typa"], $_POST["descriptiona"], $_POST["datea"], $_POST["durationa"], $_POST["timea"]));

    $result0 = $stmt->fetch(PDO::FETCH_ASSOC);

   if(strcmp($result0['Typ'], $_POST["typa"]) == 0 and strcmp($result0['Beschreibung'], $_POST["descriptiona"]) == 0 and strcmp($result0['Dauer'], $_POST["durationa"]) == 0 and strcmp($result0['Datum'], $_POST["datea"] == 0) and strcmp($result0['Zeit'], $_POST["timea"]))
    {
        echo "Datensatz existiert bereits";
    }
    else
    {
        
        $Auf = $_POST["typa"];
        // Auffüllstunde eintragen und dann ID holen */
        if($Auf=="default"){
            
            $Auf = $_POST["typa2"];
        }
        
    	$stmt0=$pdo->prepare("insert into Auffullstunden (Typ, Beschreibung, Datum, Dauer, Zeit) values (?, ?, ?, ?, ?)");
    	$stmt0->execute(array($Auf, $_POST["descriptiona"], $_POST["datea"], $_POST["durationa"], $_POST["timea"]));

		$stmt1=$pdo->prepare("select ID from Auffullstunden where Typ = ? and Beschreibung = ? and Datum = ? and Dauer = ? and Zeit = ?");
		$stmt1->execute(array($Auf, $_POST["descriptiona"], $_POST["datea"], $_POST["durationa"], $_POST["timea"]));

		$result1 = $stmt1->fetch(PDO::FETCH_ASSOC);

		$stmt2=$pdo->prepare("insert into BenutzerAuf values (?, ?, ?)");
		$stmt2->execute(array($_SESSION["Benutzername"], $result1['ID'], 0));
	}

    header("Location: ../index.php");
	die();
?>