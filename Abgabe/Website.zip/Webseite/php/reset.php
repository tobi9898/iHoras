<?php  
    
	// Benutzer löschen

	require_once"connect_db.php";

    $stmt=$pdo->prepare("delete from Auffullstunden where ID > 0");
    $stmt->execute(); 

	$stmt1=$pdo->prepare("delete from BenutzerAuf where ID > 0");
    $stmt1->execute(); 

	$stmt2=$pdo->prepare("delete from KollegialeTatigkeiten where AID > 0");
    $stmt2->execute(); 

    header("Location: ../admin.php");
	die();
?> 
