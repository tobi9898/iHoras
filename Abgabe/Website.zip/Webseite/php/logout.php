<?php
     
     session_start();
     
        if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
            
            session_unset();
            session_destroy();
        }

     header("Location: ../login.php");

die();

?>

