<?php
 	session_start();
        if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
            $user = $_SESSION['Benutzername'];
        }else{
          header('Location: ../login.php');
        }

	require_once 'connect_db.php';

    // Überprüfen ob Element schon vorhanden ist

    $stmt0=$pdo->prepare("select * from Auffullstunden where Typ = ? and Beschreibung = ? and Datum = ? and Dauer = ? and Zeit = ?");
    $stmt0->execute(array($_POST["typk"], $_POST["descriptionk"], $_POST["datek"], $_POST["durationk"], $_POST["timek"]));

    $result0 = $stmt0->fetch(PDO::FETCH_ASSOC);

    if(strcmp($result0['Typ'], $_POST["typk"]) == 0 and strcmp($result0['Beschreibung'], $_POST["descriptionk"]) == 0 and strcmp($result0['Dauer'], $_POST["durationk"]) == 0 and strcmp($result0['Datum'], $_POST["datek"]) and strcmp($result0['Zeit'], $_POST["timea"]) == 0)
    {
        echo "Datensatz existiert bereits";
    }
    else
    {
        $Kol = $_POST["typk"];
            
        // Auffüllstunde eintragen und dann ID holen */
        if($Kol=="default"){
            
            $Kol = $_POST["typk2"];
        }
        
        
        
        $stmt=$pdo->prepare("insert into Auffullstunden (Typ, Beschreibung, Datum, Dauer, Zeit) values (?, ?, ?, ?, ?)");
        $stmt->execute(array($Kol, $_POST["descriptionk"], $_POST["datek"], $_POST["durationk"], $_POST["timek"]));

        $stmt1=$pdo->prepare("select ID from Auffullstunden where Typ = ? and Beschreibung = ? and Datum = ? and Dauer = ?");
        $stmt1->execute(array($Kol, $_POST["descriptionk"], $_POST["datek"], $_POST["durationk"])); 

        $result1 = $stmt1->fetch(PDO::FETCH_ASSOC);

        // Protokoll eintragen und dann ID holen
		
        $stmt2=$pdo->prepare("insert into Protokolle (Protokolant, Text, Art, Bezeichnung, Datum, Ort, Dauer) values (?, ?, ?, ?, ?, ?, ?)");
        $stmt2->execute(array($_SESSION["Benutzername"], $_POST["protocoll"], $Kol, $_POST["descriptionk"], $_POST["datek"], "Brixen", $_POST["durationk"]));

        $stmt3=$pdo->prepare("select ID from Protokolle where Text = ?");
        $stmt3->execute(array($_POST["protocoll"])); 

        $result2 = $stmt3->fetch(PDO::FETCH_ASSOC);
        echo $result2['ID'];

        // ID von Auffüllstunde und Protokoll in Kollegiale Tätigkeit eintragen 

        $stmt4=$pdo->prepare("insert into KollegialeTatigkeiten values (?, ?)");
        $stmt4->execute(array($result1['ID'], $result2['ID']));
		
		$stmt4=$pdo->prepare("insert into BenutzerAuf values (?, ?, ?)");
        $stmt4->execute(array($_SESSION["Benutzername"], $result1['ID'], 0));
    }

    header("Location: ../index.php");
	die();
?>