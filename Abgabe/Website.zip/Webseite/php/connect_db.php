<?php
    $dsn="mysql:host=mysql.hostinger.de;dbname=u102794315_ihora;";
    $user2="u102794315_admin";
    $pass="Admin123";
    $pdo= new PDO($dsn, $user2, $pass);
?>