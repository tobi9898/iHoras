<?php
     session_start();
     if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
        $user = $_SESSION['Benutzername'];
     }else{
        header('Location: ../login.php');
     }

	require_once 'connect_db.php';

    // Um a Auffüllstunde zi löschen muis man Typ Datum und Dauer ungebn

	$stmt=$pdo->prepare("select ID from Auffullstunden where Typ = ? and Datum = ? and Zeit = ?");
    $stmt->execute(array($_POST["typkl"], $_POST["datekl"], $_POST["timekl"]));

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt0=$pdo->prepare("delete from Auffullstunden where ID = ?");
    $stmt0->execute(array($result["ID"]));

    $stmt1=$pdo->prepare("delete from BenutzerAuf where Benutzername = ? and ID = ?");
    $stmt1->execute(array($_SESSION['Benutzername'], $result["ID"]));

    $stmt2=$pdo->prepare("select ProtokollID from KollegialeTatigkeiten where AID = ?");
    $stmt2->execute(array($result["ID"]));

    $result1 = $stmt2->fetch(PDO::FETCH_ASSOC);

    $stmt3=$pdo->prepare("delete from KollegialeTatigkeiten where AID = ?");
    $stmt3->execute(array($result["ID"]));

    $stmt4=$pdo->prepare("delete from Protokolle where ID = ?");
    $stmt4->execute(array($result1["ID"]));

    header("Location: ../index.php");
	die();
?>