<?php  

    // Benutzer loeschen

	require_once 'connect_db.php';

    $stmt=$pdo->prepare("delete from Benutzer where Benutzername = ?");
    $stmt->execute(array($_GET["benutzername"]));

	$stmt1=$pdo->prepare("delete from BenutzerAuf where Benutzername = ?");
    $stmt1->execute(array($_GET["benutzername"])); 

	$stmt2=$pdo->prepare("delete from Auffullstunden where ID not in (select ID from BenutzerAuf)");
    $stmt2->execute();

	$stmt3=$pdo->prepare("delete from KollegialeTatigkeiten where AID not in (select ID as AID from Auffullstunden)");
    $stmt3->execute();

    header("Location: ../delete.php");
	die();

?> 