<?php
     session_start();
     if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
        $user = $_SESSION['Benutzername'];
     }else{
        header('Location: ../login.php');
     }

		require_once 'connect_db.php';


    $stmt1=$pdo->prepare("update BenutzerAuf set Freigeben = 1 where Benutzername = ?");
    $stmt1->execute(array($_SESSION['Benutzername']));

    header('Location: ../profil.php');

?>