<?php
    // Passwort eines Benutzers ändern    

	require_once"connect_db.php";

    $stmt=$pdo->prepare("update Benutzer set Passwort = ? where benutzername = ?");
    $stmt->execute(array(md5($_POST["passwort"]), $_POST["benutzername"]));  
    
	header("Location: ../update.php");
	die();
?> 