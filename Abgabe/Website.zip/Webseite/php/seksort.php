<?php
     session_start();
     if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
        $user = $_SESSION['Benutzername'];
     }else{
        header('Location: ../login.php');
     }

    require_once 'connect_db.php';
    
    // Aus einer Select Box mit allen Lehrern kann ein Lehrer ausgewählt werden und dessen Auffüllstunden werden dann aufgelistet

    $stmt0=$pdo->prepare("Select Name from Benutzer where Typ = 'Lehrer'");

    $stmt0->execute();

    while($result0 = $stmt0>fetch(PDO::FETCH_ASSOC))
    {
        echo $result0["Name"];
    }

    // Abfrage um die Daten zu holen, wird mit Button ausgelöst

	$stmt=$pdo->prepare("select * from Auffullstunden natural join BenutzerAuf where Benutzername = ? and Freigeben = 1");
    $stmt->execute($_POST['Benutzername']);

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Freigeben der Auffüllstunden eines Lehrers

    $stmt1=$pdo->prepare("update BenutzerAuf set Freigeben = 1 where Benutzername = ?");
    $stmt1->execute($_SESSION['Benutzername']);

    // Rückgängig machen
    
    $stmt1=$pdo->prepare("update BenutzerAuf set Freigeben = 0 where Benutzername = ?");
    $stmt1->execute($_SESSION['Benutzername']);
?>