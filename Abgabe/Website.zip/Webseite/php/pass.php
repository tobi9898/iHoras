<?php
 session_start();
        if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
            $user = $_SESSION['Benutzername'];
        }else{
          header('Location: login.php');
        }


   	require_once 'connect_db.php';

    $stmt=$pdo->prepare("update Benutzer set Passwort = ? where Benutzername = ?;");

    $stmt->execute(array($_GET['Password'], $user));


    header('Location: ../profil.php');
?>