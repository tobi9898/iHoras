<?php   
    // Benutzer hinzufügen

	require_once"connect_db.php";

    $stmt=$pdo->prepare("insert into Benutzer(Benutzername, Typ, Passwort, Name, Arbeitsstunden) values (?, ?, ?, ?, ?)");
    $stmt->execute(array($_POST["benutzername"], $_POST["typ"], md5($_POST["passwort"]), $_POST["name"], $_POST["arbeitsstunden"]));
    
	header("Location: ../insert.php");
	die();
?>     