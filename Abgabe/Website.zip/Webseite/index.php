﻿<?php
session_start();
if ( isset( $_SESSION[ 'Benutzername' ] ) && isset( $_SESSION[ 'Passwort' ] ) ) {

	$user = $_SESSION[ 'Benutzername' ];

	if ( $_SESSION[ 'Typ' ] == "Administrator" ) {

		header( 'Location: admin.php' );
		die();

	} else if ( $_SESSION[ 'Typ' ] == "Sekretariat" ) {

		header( 'Location: sek.php' );
		die();
	}

} else {
	header( 'Location: login.php' );
	die();
}
require_once 'php/connect_db.php';
?>

<!DOCTYPE html>
<html lang="de">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>iHoras - Dashboard</title>

	<!-- Favicon -->
	<link rel="shortcut icon" href="img/ihoras-fav.png">

	<!-- Bootstrap -->
	<link href="css/bootstrap.css" rel="stylesheet">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">

</head>

<body class="container-fluid">
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.php">iHoras</a>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="defaultNavbar1">
				<ul class="nav navbar-nav">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Funktionen<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="index.php">Dashboard</a>
							</li>
							<li class="divider"></li>
							<li><a href="calendar.php">Kalender</a>
							</li>
							<li><a href="protokol.php">Protokolle</a>
							</li>
						</ul>
					</li>
					<li><a href="help.php">Hilfe</a>

				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="profil.php">Profil</a>
							</li>

							<li><a href="php/logout.php">Abmelden</a>

							</li>
						</ul>
					</li>
				</ul>
			</div>
			<!-- /.navbar-collapse -->
		</div>
		<!-- /.container-fluid -->
	</nav>
	<div style="height: 60px"></div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<h1 class="text-center headline">Herzlich Willkommen <?php echo $_SESSION["Benutzername"]; ?></h1>
			</div>
		</div>
	</div>
	<hr>

	<div class="container-fluid">
		<div class="tablewidth">
			<h2>Art der Auffüllstunden</h2>
			<div class="row">
				<table class="table" style="align-items: center">
					<thead>
						<tr>
							<th>Art</th>
							<th>Anzahl Stunden</th>
							<th>Abgeschlossen</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Stunden mit Schüler</td>
							<?php echo"<td> "; 
							$stmt0 = $pdo->prepare( "SELECT sum(Dauer) FROM ((SELECT ID, Dauer FROM Auffullstunden WHERE ID NOT IN ( SELECT AID AS ID FROM KollegialeTatigkeiten )) t  natural join (SELECT * FROM Benutzer  NATURAL JOIN BenutzerAuf WHERE Benutzername = ?) t2 )" );
								
								//$stmt0 = $pdo->prepare( "select sum(Dauer) as neueDauer from Auffullstunden natural join (select ID from BenutzerAuf natural join (select Benutzername from Benutzer where Benutzername = ?)) " );

								$stmt0->execute( array($_SESSION["Benutzername"]) ); //Benutzer holen aus der Session

								$result0 = $stmt0->fetch( PDO::FETCH_ASSOC );
								echo $result0["sum(Dauer)"];
  
								echo "</td><td>";


								$result1 = $result0[ "sum(Dauer)" ] / 34;
								$result1 = round( $result1, 2 ) * 100;
							
								if($result1>100)
								{
									$result1 = 100;
								}

								echo "
    		<div class='progress'>
         <div class='progress-bar progress-bar-primary' role='progressbar' aria-valuenow='0'
              aria-valuemin='0' aria-valuemax='100' id='aufstunden'  style='width:" . $result1 . "%'>" . $result1 . "%</div>
            
              </div></td>
              
              
          </tr>";
								$stmt0 = $pdo->prepare( "SELECT sum(Dauer) FROM ((SELECT ID, Dauer FROM Auffullstunden WHERE ID IN ( SELECT AID AS ID FROM KollegialeTatigkeiten )) t  natural join (SELECT * FROM Benutzer  NATURAL JOIN BenutzerAuf WHERE Benutzername = ?) t2 )" );

								$stmt0->execute( array($_SESSION["Benutzername"]) );

								$result0 = $stmt0->fetch( PDO::FETCH_ASSOC );

								$result1 = $result0[ "sum(Dauer)" ] / 68;
								$result1 = round( $result1, 2 ) * 100;

								if($result1>100)
								{
									$result1 = 100;
								}

								echo "     
          <tr>
            <td>Kollegiale Stunden</td>
            <td> ";
							
								echo $result0['sum(Dauer)'];
						
								echo "
			  </td> 
            <td><div class='progress'>
                <div class='progress-bar progress-bar-success' role='progressbar' aria-valuenow='0'
  aria-valuemin='0' aria-valuemax='100' id='kolltaetig'  style='width:" . $result1 . "%'>" . $result1 . "%</div></div></td>
                
                ";
								?>
						</tr>
					</tbody>
				</table>
			</div>
		</div>


		<br>
		<div class="container2">
			<div class="row">
				<div class="hourpanel col-md-6 ">

					<div class="panel panel-primary">
						<div class="panel-heading">
							<h3 class="panel-title txtalign"> Stunden hinzufügen</h3>
						</div>
						<div class="panel-body">
							<div class="form-group txtalign">
								<button type="button" class="btn btn-primary" data-target="#aufstundenmodal" data-toggle="modal">Auffüllstunden hinzufügen</button>
							</div>
							<div class="form-group txtalign">
								<button type="button" class="btn btn-primary" data-target="#kolstundenmodal" data-toggle="modal">Kollegiale Tätigkeiten hinzufügen</button>
							</div>
						</div>
					</div>
				</div>

				<div class="hourpanel col-md-6">

					<div class="panel panel-primary">
						<div class="panel-heading">
							<h3 class="panel-title txtalign"> Stunden löschen</h3>
						</div>
						<div class="panel-body">
							<div class="form-group txtalign">
								<button type="button" class="btn btn-primary" data-target="#aufstundenmodalloeschen" data-toggle="modal">Auffüllstunden löschen</button>
							</div>
							<div class="form-group txtalign">
								<button type="button" class="btn btn-primary" data-target="#kolstundenmodalloeschen" data-toggle="modal">Kollegiale Tätigkeiten löschen</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<br>

		<div class="tablewidth">
			<h2>Detaillierte Art der Auffüllstunden</h2>
			<div class="row">
				<table class="table" style="align-items: center">
					<thead>
						<tr>
							<th>Art</th>
							<th>Anzahl Stunden</th>
							<th>Abgeschlossen</th>
						</tr>
					</thead>
					<tbody>

						<?php 	
							
								$stmt0 = $pdo->prepare( "SELECT neuTyp, sum(Dauer) FROM ((SELECT ID, Typ as neuTyp, Dauer FROM Auffullstunden WHERE ID NOT IN ( SELECT AID AS ID FROM KollegialeTatigkeiten )) t  natural join (SELECT * FROM Benutzer NATURAL JOIN BenutzerAuf WHERE Benutzername = ?) t2 ) group by neuTyp order by ID desc");

								$stmt0->execute( array($_SESSION["Benutzername"]) );

								while($result = $stmt0->fetch(PDO::FETCH_ASSOC))
								{
									echo "<tr>";
									echo "<td>" . $result['neuTyp'] . "</td>";
									echo "<td>" . $result['sum(Dauer)'] . "</td>";

									$result0 = $result[ "sum(Dauer)" ] / 34;
									$result0 = round( $result0, 2 ) * 100;

									if($result0>100)
									{
										$result0 = 100;
									}

									echo "<td><div class='progress'><div class='progress-bar progress-bar-primary' role='progressbar' aria-valuenow='0' aria-valuemin='0' aria-valuemax='100' id='aufstunden' style='width:" . $result0 . "%'>" . $result0 . "%</div></div></td></tr>";


									echo "</tr>";
								}
						
								$stmt0 = $pdo->prepare( "SELECT neuTyp, sum(Dauer) FROM ((SELECT ID, Typ as neuTyp, Dauer FROM Auffullstunden WHERE ID IN ( SELECT AID AS ID FROM KollegialeTatigkeiten )) t  natural join (SELECT * FROM Benutzer  NATURAL JOIN BenutzerAuf WHERE Benutzername = ?) t2 ) group by neuTyp order by ID desc" );

								$stmt0->execute( array($_SESSION["Benutzername"]) );

								while($result = $stmt0->fetch(PDO::FETCH_ASSOC))
								{
									echo "<tr>";
									echo "<td>" . $result['neuTyp'] . "</td>";
									echo "<td>" . $result['sum(Dauer)'] . "</td>";

									$result0 = $result[ "sum(Dauer)" ] / 68;
									$result0 = round( $result0, 3 ) * 100;
									
									if($result0>100)
									{
										$result0 = 100;
									}

									echo "<td><div class='progress'><div class='progress-bar progress-bar-success' role='progressbar' aria-valuenow='0' aria-valuemin='0' aria-valuemax='100' id='aufstunden'  style='width:" . $result0 . "%'>" . $result0 . "%</div></div></td></tr>";


									echo "</tr>";
								}
							?>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<hr>
		<div class="row">
			<div class="text-center col-md-6 col-md-offset-3">
				<p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; iHoras
				</p>
			</div>
		</div>
	</div>

	<!-- Modal Auffüllstunden -->
	<div id="aufstundenmodal" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Auffüllstunde hinzufügen</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" action="./php/ASinsert.php" method="post">
						<div class="form-group">
							<label class="control-label col-sm-2" for="typ">Typ auswählen:</label>
							<div class="col-sm-10">
								<select class="form-control" id="typa" name="typa" onChange="checkData">

									<?php 	
	  								echo "<option value='default' selected>Typ auswählen</option>";
									$stmt0 = $pdo->prepare( "SELECT * FROM ((SELECT ID, Typ as neuTyp, Dauer FROM Auffullstunden WHERE ID NOT IN ( SELECT AID AS ID FROM KollegialeTatigkeiten )) t  natural join (SELECT * FROM Benutzer  NATURAL JOIN BenutzerAuf WHERE Benutzername = ?) t2 ) group by neuTyp" );
									$stmt0->execute( array($_SESSION["Benutzername"]) );
									while($result = $stmt0->fetch(PDO::FETCH_ASSOC))
									{
									$temp='"'.$result[ "neuTyp"].'"';
									echo "<option value=$temp >" . $result[ "neuTyp"] . "</option>";
									} 
									
								?>

								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="typa"> oder Typ eingeben:</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="typauf" placeholder="Typ eingeben:" name="typa2">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="description">Beschreibung:</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="descriptiona" placeholder="Beschreibung eingeben:" name="descriptiona" required>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="date">Datum:</label>
							<div class="col-sm-10">
								<input type="date" class="form-control" id="datea" placeholder="Datum eingeben: " name="datea"  min="2016-01-01" max="2036-12-31" required>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="date">Zeit:</label>
							<div class="col-sm-10">
								<input type="time" class="form-control" id="timea" placeholder="Zeit eingeben: " name="timea">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="duration">Dauer:</label>
							<div class="col-sm-10">
								<input type="number" min="0.5" step="0.5" class="form-control" id="durationa" placeholder="Dauer eingeben: " name="durationa" required>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">
								<button type="submit" class="btn btn-default">Speichern</button>
							</div>
						</div>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Schließen</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Modal Kollegiale Tätigkeiten -->
	<div id="kolstundenmodal" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Kollegiale Tätigkeit hinzufügen</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" action="./php/KTinsert.php" method="post">
						<div class="form-group">
							<label class="control-label col-sm-2" for="typ">Typ:</label>
							<div class="col-sm-10">
								<select class="form-control" id="typk" name="typk">

									<?php 
								  	echo "<option value='default' selected>Typ auswählen</option>";
									$stmt0 = $pdo->prepare( "SELECT * FROM ((SELECT ID, Typ as neuTyp, Dauer FROM Auffullstunden WHERE ID IN ( SELECT AID AS ID FROM KollegialeTatigkeiten )) t  natural join (SELECT * FROM Benutzer  NATURAL JOIN BenutzerAuf WHERE Benutzername = ?) t2 ) group by neuTyp" );
									$stmt0->execute( array($_SESSION["Benutzername"]) );
									while($result = $stmt0->fetch(PDO::FETCH_ASSOC))
									{
									$temp='"'.$result[ "neuTyp"].'"';
									echo "<option value=$temp >" . $result[ "neuTyp"] .  "</option>";	
									
									} 
								?>

								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="description"> oder Typ eingeben:</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="typkol" placeholder="Typ eingeben:" name="typk2">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="description">Beschreibung:</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="descriptionk" placeholder="Beschreibung eingeben:" name="descriptionk" required>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="date">Datum:</label>
							<div class="col-sm-10">
								<input type="date" class="form-control" id="datek" placeholder="Datum eingeben: " name="datek" min="2016-01-01" max="2036-12-31" required>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="date">Zeit:</label>
							<div class="col-sm-10">
								<input type="time" class="form-control" id="timek" placeholder="Zeit eingeben: " name="timek">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="duration">Dauer:</label>
							<div class="col-sm-10">
								<input type="number" min="0.5" step="0.5" class="form-control" id="durationk" placeholder="Dauer eingeben: " name="durationk" required>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="protokoll">Protokoll:</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="protocoll" placeholder="Protokoll: " name="protocoll" required>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">
								<button type="submit" class="btn btn-default">Speichern</button>
							</div>
						</div>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Schließen</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Modal Auffüllstunden löschen -->
	<div id="aufstundenmodalloeschen" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Auffüllstunde löschen</h4>
				</div>
				<div class="modal-body">
				<div class="container-fluid">
					<form class="form-horizontal" action="./php/ASloeschen.php" method="post">
						<div class="form-group">
							<div class="">
								<select class="form-control" id="typal" name="typal">  

									<?php 	
										
	  								echo "<option value='default' selected>Typ auswählen</option>";
									$stmt0 = $pdo->prepare( "select Typ from Auffullstunden natural join BenutzerAuf where Benutzername = ? group by Typ");
									$stmt0->execute(array($_SESSION["Benutzername"]));
									while($result = $stmt0->fetch(PDO::FETCH_ASSOC))
									{
									$temp='"'.$result[ "Typ"].'"';
									echo "<option value=$temp >" . $result[ "Typ"] . "</option>";
									} 
									
								?>

								</select>
							</div>
						</div>
						<div class="form-group">
							

			


					<select class="form-control" id="dateal" name="dateal">

									<?php 	
								
	  								echo "<option value='default' selected>Datum auswählen</option>";
									$stmt0 = $pdo->prepare( "select Datum from Auffullstunden natural join (select * from BenutzerAuf where Benutzername = ?) as t" );
									$stmt0->execute( array($_SESSION["Benutzername"]));
									while($result = $stmt0->fetch(PDO::FETCH_ASSOC))
									{
										$temp='"'.$result["Datum"].'"';
										echo "<option value=$temp >" . $result["Datum"] . "</option>";
										
									} 
									
								?>

								</select>
						</div>
						<div class="form-group">

							<select class="form-control" id="timeal" name="timeal">

									<?php 	

									

	  								echo "<option value='default' selected> Zeit auswählen</option>";
									$stmt0 = $pdo->prepare( "select date_format(Zeit,'%H:%i:%s') Zeit from Auffullstunden natural join (select * from BenutzerAuf where Benutzername = ?) as t2" );
									$stmt0->execute( array($_SESSION["Benutzername"]));
									while($result = $stmt0->fetch(PDO::FETCH_ASSOC))
									{
			
									$temp='"'.$result["Zeit"].'"';
									echo "<option value=$temp >" . $result["Zeit"] . "</option>";
										
									} 
									
								?>
								
								</select>
						</div>
						
						<div class="form-group">
							<div>
								<button type="submit" class="btn btn-default">Löschen</button>
							</div>
						</div>
					</form>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Schließen</button>
				</div>
			</div>
		</div>
	</div>
	
	<!-- Modal Kollegiale Tätigekeiten löschen -->
	<div id="kolstundenmodalloeschen" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Kollegiale Tätigkeit löschen</h4>
				</div>
				<div class="modal-body">
				<div class="container-fluid">
					<form class="form-horizontal" action="./php/KTloeschen.php" method="post">
						<div class="form-group">
							<div class="">
								<select class="form-control" id="typkl" name="typkl" >

									<?php 
								  	echo "<option value='default' selected>Typ auswählen</option>";
									$stmt6 = $pdo->prepare( "select Typ from Auffullstunden natural join (select * from BenutzerAuf where Benutzername = ?) as t where ID in (select AID as ID from KollegialeTatigkeiten)" );
									$stmt6->execute( array($_SESSION["Benutzername"]) );
									while($result = $stmt6->fetch(PDO::FETCH_ASSOC))
									{
									$temp='"'.$result[ "Typ"].'"';
									echo "<option value=$temp >" . $result[ "Typ"] . "</option>";	
									echo $temp;
									} 
								?>

								</select>
							</div>
						</div>
						<div class="form-group">
							<select class="form-control" id="datekl" name="datekl" >

									<?php 
								  	echo "<option value='default' selected>Datum auswählen</option>";
									$stmt7 = $pdo->prepare( "select Datum from Auffullstunden natural join (select * from BenutzerAuf where Benutzername = ?) as t where ID in (select AID as ID from KollegialeTatigkeiten)
									" );
									$stmt7->execute( array($_SESSION["Benutzername"]) );
									while($result = $stmt7->fetch(PDO::FETCH_ASSOC))
									{
									$temp='"'.$result[ "Datum"].'"';
									echo "<option value=$temp >" . $result[ "Datum"] . "</option>";	
									echo $temp;
									} 
								?>

								</select>
						</div>
						<div class="form-group">
									<select class="form-control" id="timekl" name="timekl">

									<?php 
								  	echo "<option value='default' selected>Zeit auswählen</option>";
									$stmt8 = $pdo->prepare( "select date_format(Zeit,'%H:%i:%s') Zeit from Auffullstunden natural join (select * from BenutzerAuf where Benutzername = ?) as t where ID in (select AID as ID from KollegialeTatigkeiten)" );
									$stmt8->execute( array($_SESSION["Benutzername"]) );
									while($result = $stmt8->fetch(PDO::FETCH_ASSOC))
									{
									$temp='"'.$result[ "Zeit"].'"';
									echo "<option value=$temp >" . $result[ "Zeit"] . "</option>";	
									echo $temp;
									} 
								?>

								</select>
						</div>
						<div class="form-group">
							<div>
								<button type="submit" class="btn btn-default">Löschen</button>
							</div>
						</div>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Schließen</button>
				</div>
				</div>
			</div>
		</div>
	</div>



	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>

	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.js"></script>

	<!-- Datanbankanbindung -->
	<script src="js/init.js"></script>

</body>

</html>