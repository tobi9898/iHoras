<?php
session_start();
if ( isset( $_SESSION[ 'Benutzername' ] ) && isset( $_SESSION[ 'Passwort' ] ) ) {
	$user = $_SESSION[ 'Benutzername' ];
} else {
	header( 'Location: login.php' );
}
require_once 'php/connect_db.php';
?>

<!DOCTYPE html>
<html lang="de">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>iHoras - Profil</title>

	<!-- Favicon -->
	<link rel="shortcut icon" href="img/ihoras-fav.png">

	<!-- Bootstrap -->
	<link href="css/bootstrap.css" rel="stylesheet">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">


	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body class="container-fluid">
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.php">iHoras</a>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="defaultNavbar1">
				<ul class="nav navbar-nav">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Funktionen<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="index.php">Dashboard</a>
							</li>
							<li class="divider"></li>
							<li><a href="calendar.php">Kalender</a>
							</li>
							<li><a href="protokol.php">Protokolle</a>
							</li>
						</ul>
					</li>
					<li><a href="help.php">Hilfe</a>

				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="profil.php">Profil</a>
							</li>
							<li><a href="php/logout.php">Abmelden</a>
						</ul>
						</li>
				</ul>
			</div>
			<!-- /.navbar-collapse -->
		</div>
		<!-- /.container-fluid -->
	</nav>
	<div style="height: 60px"></div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<h1 class="text-center headline">iHoras - Profil</h1>
			</div>
		</div>
		<hr>
	</div>



		<div class="container">
			<div class="jumbotron">
				<div class="row">
					<div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">

						<img src="img/profile-pics.png" alt="stack photo" class="img img-responsive">
					</div>
					<div class="col-md-8 col-xs-12 col-sm-6 col-lg-8">
						<div class="container" style="border-bottom:1px solid black">

							<?php


							//----------------------

							$stmt0 = $pdo->prepare( "select * from  Benutzer where Benutzername = ?" );

							$stmt0->execute( array( $_SESSION[ 'Benutzername' ] ) );


							$result0 = $stmt0->fetch( PDO::FETCH_ASSOC );


							echo " <h2>" . $result0[ "Name" ] . "</h2>";



							echo "
                            </div>
                            <hr>
                            <ul class='container details'>
                                <li>
                                    <p><span class='glyphicon glyphicon-education' style='width:50px;'>
                                        
                                        </span>" . $result0[ "Typ" ] . "</p></li>
                                <li>
                                    <p><span class='glyphicon glyphicon-user' style='width:50px;'></span>" . $result0[ "Benutzername" ] . "</p></li>
                              
                                <li>
                                    <p><span class='glyphicon glyphicon-hourglass' style='width:50px;'></span>Arbeitsstunden: " . $result0[ "Arbeitsstunden" ] . "</p></li>"

							?>

							</ul>
						</div>
					</div>
				</div>
			</div>

	<div class="form-group">
		<div class="centeralignment">
			<button type="submit" class="btn btn-primary buttonpadding" onClick="freigeben()">Stunden freigeben</button>
		</div>
	</div>
	<div class="form-group">

		<div class="centeralignment">
			<button type="button" class="btn btn-primary buttonpadding" data-target="#Passmodal" data-toggle="modal">Password ändern</button>
		</div>
	</div>
		<div id="Passmodal" class="modal fade" role="dialog">

			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Password ändern</h4>
					</div>
					<div class="modal-body">
						<form class="form-horizontal" method="post">

							<div class="form-group">
								<label class="control-label col-sm-2" for="typ">Altes Password:</label>
								<div class="col-sm-10">
									<input type="password" class="form-control" id="altPassword" name="altPassword" required>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="description">Neues Password:</label>
								<div class="col-sm-10">
									<input type="password" class="form-control" id="Password" name="Password" required>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="description">Neues Password bestätigen:</label>
								<div class="col-sm-10">
									<input type="password" class="form-control" id="Password2" name="Password2" required>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-default">Speichern</button>

								</div>
							</div>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Schließen</button>
					</div>
				</div>
			</div>
		</div>

		<?php

		if ( isset( $_POST[ 'altPassword' ] ) && isset( $_POST[ 'Password' ] ) && isset( $_POST[ 'Password2' ] ) ) {

			$Result = $pdo->prepare( "select Passwort from Benutzer where Benutzername = ?" );

			$Result->execute( array( $_SESSION[ 'Benutzername' ] ) );

			$datensatz = $Result->fetch( PDO::FETCH_ASSOC );

			$altpass = $datensatz[ 'Passwort' ];




			if ( ( md5( $_POST[ 'altPassword' ] ) == $altpass ) && ( $_POST[ 'Password' ] == $_POST[ 'Password2' ] ) ) {


				echo "<script language='javascript'>window.location='php/pass.php?Password=" . md5( $_POST[ 'Password' ] ) . "';</script>";

			} else {

				echo " <h4 class='text-center' style='color:red'>Passwort nicht geändert </h4>";

			}


		}
		?>

<div class="container-fluid">

		<hr>
		<div class="row">
			<div class="text-center col-md-6 col-md-offset-3">
				<p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; iHoras</p>
			</div>
		</div>
	</div>
	
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.3.min.js"></script>

		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="js/bootstrap.js"></script>
		
		<script src="js/init.js"></script>

</body>

</html>