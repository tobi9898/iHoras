<?php
session_start();
if ( isset( $_SESSION[ 'Benutzername' ] ) && isset( $_SESSION[ 'Passwort' ] ) ) {
	$user = $_SESSION[ 'Benutzername' ];
} else {
	header( 'Location: login.php' );
}
require_once 'php/connect_db.php';
?>

<!DOCTYPE html>
<html lang="de">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>iHoras - Hilfe</title>

	<!-- Favicon -->
	<link rel="shortcut icon" href="img/ihoras-fav.png">

	<!-- Bootstrap -->
	<link href="css/bootstrap.css" rel="stylesheet">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">


	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body class="container-fluid">
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.php">iHoras</a>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="defaultNavbar1">
				<ul class="nav navbar-nav">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Funktionen<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="index.php">Dashboard</a>
							</li>
							<li class="divider"></li>
							<li><a href="calendar.php">Kalender</a>
							</li>
							<li><a href="protokol.php">Protokolle</a>
							</li>
						</ul>
					</li>
					<li><a href="help.php">Hilfe</a>
					</li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account<span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="profil.php">Profil</a>
							</li>
							<li><a href="php/logout.php">Abmelden</a>
						</ul>
						</li>
				</ul>
			</div>
			<!-- /.navbar-collapse -->
		</div>
		<!-- /.container-fluid -->
	</nav>
	<div style="height: 60px"></div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<h1 class="text-center headline">iHoras - Hilfe</h1>
			</div>
		</div>
		<hr>
	</div>

<div class="container-fluid">
	<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title"> Dashboard</h3>
		</div>
		<div class="panel-body">
		<p class="text-center txtsize">Das Dashboard ist die Startseite. Auf dieser werden die Auffüllstunden oder Kollegialen Tätigkeiten grafisch dargsetellt und aufgelistet.</p>
		<br>
		<img class="img-responsive center-block" width="70%" src="img/dashboard.PNG">
		<br>
		<p class="text-center txtsize">Über die blauen Buttons in der Mitte können Sie eine Auffüllstunde/Kollegialen Tätigkeit hinzufügen.</p>
		<br>
		<img src="img/hinzufugen.PNG" class="img-responsive center-block">
		<br>
		<p class="text-center txtsize">Wählen Sie einen Typ aus oder geben Sie einen neuen Typ ein (wenn Sie einen Typ schon mal benutzt haben wählen Sie diesen aus). Beachten Sie dass Sie entwerder einen Typ auswählen oder einen Typ erzeugen können, nicht aber beides gleichzeitig!</p>
		<p class="text-center txtsize">Das Datum und die Zeit können Sie händisch eintragen oder aus vorgefertigten Felder auswählen. Gleiches gilt bei der Dauer! Beachten Sie dass die Dauer entwerder eine halbe- oder volle Stunde dauert, d.h. Sie können entwerder 1 Stunde oder 1,5 Stunden eingeben nicht aber 1,2 Stunden.</p>
		<p class="text-center txtsize">Über den Speichern Button tragen Sie die Stunden ein! Bei einer kollegialen Tätigkeit muss zudem der Protokollname eingegeben werden.</p>
		</div>
	</div>
	
		<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title"> Kalender</h3>
		</div>
		<div class="panel-body">
		<img src="img/calendar.PNG" width="70%" class="img-responsive center-block">
		<br>
		<p class="text-center txtsize">Über den implementierten Kalender werden die eingegebenen Stunden dargestellt. Dabei können Sie zwischen den 3 Ansichte (Monat, Woche oder Tag) wählen. Über den Button "Heute" gelangt man auf das heutige Datum und über die Pfeiltasten oben links kann zwischen Monaten, Wochen oder Tagen hin und her gewechselt werden.</p>
		</div>
	</div>
	
		<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title"> Profil</h3>
		</div>
		<div class="panel-body">
		<p class="text-center txtsize"> Auf der Profilseite sehen Sie Informationen zu Ihrem Profil und Sie können gegebenfalls über den blauen Button dass Passwort ändern </p>
		<br>
		<img class="img-responsive center-block" width="70%" src="img/profil.PNG">
		<br>
		<p class="text-center txtsize">Geben Sie hierfür Ihr altes Passwort ein und nachher das neue. Zur Bestätigung muss dass Passwort bestätigt werden.</p>
		<br>
		<img class="img-responsive center-block" src="img/changepwd.PNG">
		<br>
		</div>
	</div>
	</div>

<div class="container-fluid">
	<hr>
	<div class="row">
		<div class="text-center col-md-6 col-md-offset-3">
			<p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; iHoras</p>
		</div>
	</div>
	</div>
	
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>

	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.js"></script>

</body>

</html>