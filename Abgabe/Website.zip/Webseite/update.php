<?php
 session_start();
        if(isset($_SESSION['Benutzername']) && isset($_SESSION['Passwort'])){
            $user = $_SESSION['Benutzername'];
        }else{
          header('Location: login.php');
        }

	require_once 'php/connect_db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>iHoras - Admin</title
	
		<!-- Favicon -->
	<link rel="shortcut icon" href="img/ihoras-fav.png">

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">


</head>
<body class=container-fluid>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid"> 
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#defaultNavbar1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
      <a class="navbar-brand" href="admin.php">iHoras</a></div>
    <div class="collapse navbar-collapse" id="defaultNavbar1">
      <ul class="nav navbar-nav">
        <li class=""><a href="insert.php">Einfügen<span class="sr-only"></span></a></li>
        <li class=""><a href="delete.php">Löschen<span class="sr-only"></span></a></li>
        <li class=""><a href="update.php">Ändern<span class="sr-only"></span></a></li>
      </ul>
       <ul class="nav navbar-nav navbar-right">
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="php/logout.php">Abmelden</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<div style="height: 70px"></div>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <h1 class="text-center">Admin Panel - Ändern</h1>
    </div>
  </div>
  <hr>
</div>

    <div class="container-fluid">
<form class="form" method="post">
        <label for="inputBenutzer" class="control-label ">Benutzer</label><br>
    <!-- Split button -->
<div class="btn-group">
  <button type="button" class="btn btn-primary">Benutzername wählen</button>
  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="caret"></span>
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <ul id="userlist1" class="dropdown-menu">
      <!-- PHP Benutzer holen -->    
      <?php

		$stmt = $pdo->query( "SELECT Benutzername FROM Benutzer" );
        $stmt -> execute();
		while ($result = $stmt->fetch( PDO::FETCH_ASSOC )) {
            $temp='"'.$result[ "Benutzername"].'"';
			echo "<li><a href='#' onclick='getData($temp)'>" . $result[ "Benutzername"] . "</a></li>";
		}
		?>
  </ul>
</div>
    <br>
    <br>
     <div class="form-group">
        <label for="inputBenutzer" class="control-label ">Benutzer</label>
            <input type="text" class="form-control" id="inputBenutzer" placeholder="Benutzernamen" readonly name="benutzername">
    </div>
    <div class="form-group">
        <label for="inputPassword" class="control-label ">Passwort</label>
            <input type="password" class="form-control" id="inputPasswort" placeholder="Passwort" name="passwort">
    </div>
    <div class="form-group">
        <label for="inputPassword" class="control-label ">Passwort bestätigen</label>
            <input type="password" class="form-control" id="inputPasswortCheck" placeholder="Passwort bestätigen" name="passwortcheck">
    </div>
    
    <div class="form-group">
            <button type="submit" class="btn btn-primary">Ändern</button>
    </div>
</form>
	</div>
	
	<?php

		if (isset( $_POST[ 'passwort' ] ) && isset( $_POST[ 'passwortcheck' ] ) ) {

			$Result = $pdo->prepare( "select Passwort from Benutzer where Benutzername = ?" );

			$Result->execute( array( $_POST["benutzername"]) );

			$datensatz = $Result->fetch( PDO::FETCH_ASSOC );

			$altpass = $datensatz[ 'Passwort' ];




			if (( $_POST[ 'passwort' ] == $_POST[ 'passwortcheck' ] ) ) {


				echo "<script language='javascript'>window.location='php/update.php" . md5( $_POST[ 'passwort' ] ) . "';</script>";

			} else {

				echo " <h4 class='text-center' style='color:red'>Passwort nicht geändert </h4>";

			}


		}
		?>


<div class="container-fluid">
  <hr>
  <div class="row">
    <div class="text-center col-md-6 col-md-offset-3">
      <h4>iHoras </h4>
      <p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; <a href="http://www.simon-mayrhofer.com/" >iHoras</a></p>
    </div>
  </div>
	</div>
	
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.3.min.js"></script> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
    <script src="js/init.js" type="text/javascript"></script>
</body>
</html>
