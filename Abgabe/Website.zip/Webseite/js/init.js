﻿// JavaScript Document     

function gettyp(input){
document.getElementById("typ").value=input;
} 

function getData(input){
    document.getElementById("inputBenutzer").value=input;
}

function resetcheck(){
    if (confirm("Reset durchführen!") == true) {
    location.href = "php/reset.php";
} else {
    //Nothing
}
}

function freigeben(){
	window.location="php/freigeben.php"
}
